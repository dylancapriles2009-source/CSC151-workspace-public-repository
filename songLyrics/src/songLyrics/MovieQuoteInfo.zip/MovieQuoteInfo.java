package songLyrics;

public class MovieQuoteInfo {

	public static void main(String[] args) {
	
	System.out.println("Quote: \"You don't know about real loss, because it only occurs when you've loved something more than you love yourself\"\n" +
			"Movie: Good Will Hunting\n" +
			"Character: Sean Maguire\n" +
			"Year: 1997"
			);
	
	}
}
